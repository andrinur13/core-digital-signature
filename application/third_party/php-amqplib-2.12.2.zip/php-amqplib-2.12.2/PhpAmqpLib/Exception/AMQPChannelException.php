<?php

namespace PhpAmqpLib\Exception;

/**
 * @deprecated use AMQPProtocolChannelException instead
 */
class AMQPChannelException extends AMQPException
{
}
