<?php

namespace PhpAmqpLib\Exception;

class AMQPNotImplementedException extends AMQPRuntimeException
{
}
